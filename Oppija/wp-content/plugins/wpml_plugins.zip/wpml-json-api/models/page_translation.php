<?php

require_once WPML_JSON_API_PATH.'/models/post_translation.php';

/**
 * A translation of a WPML_JSON_API_Page.
 */
class WPML_JSON_API_PageTranslation extends WPML_JSON_API_PostTranslation {
}
